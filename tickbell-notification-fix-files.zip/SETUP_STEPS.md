# TickBell notification fix setup

## What this changes

This fix keeps your current Bell and Chat database/realtime logic, but fixes the browser notification path:

1. The app now shows a visible "Enable TickBell alerts" prompt instead of silently asking/doing nothing.
2. The foreground app now displays real OS notifications through the service worker, not only sound/vibration.
3. The service worker handles foreground/background push payloads with title, body, icon, vibration, and click navigation.
4. The public VAPID key can be configured with `VITE_VAPID_PUBLIC_KEY` and must match the server private key.

## Files to copy into your repo

Copy these files over the same paths in your project:

- `src/lib/push.ts`
- `src/lib/tickbell.ts`
- `src/components/notification-permission-prompt.tsx`
- `src/components/message-notifier.tsx`
- `src/components/incoming-bell.tsx`
- `src/routes/_authenticated/route.tsx`
- `public/sw.js`

## Required environment variables

In Vercel, set these environment variables for Production and Preview:

```env
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY

VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY

VITE_VAPID_PUBLIC_KEY=YOUR_VAPID_PUBLIC_KEY
VAPID_PUBLIC_KEY=YOUR_VAPID_PUBLIC_KEY
VAPID_PRIVATE_KEY=YOUR_VAPID_PRIVATE_KEY
VAPID_SUBJECT=mailto:your-support-email@example.com
```

Important: `VITE_VAPID_PUBLIC_KEY` and `VAPID_PUBLIC_KEY` must be the public key from the same VAPID pair as `VAPID_PRIVATE_KEY`.

## Generate VAPID keys if needed

If you already have a working VAPID pair, keep it. If not, generate one locally with:

```bash
npx web-push generate-vapid-keys
```

You do not need to install `web-push` in your app for runtime. This command is only for generating keys.

## Database requirement

Your database must already have `push_subscriptions` with columns:

- `id`
- `user_id`
- `endpoint`
- `p256dh`
- `auth`
- `user_agent`
- `created_at`
- `last_seen_at`

## Test steps

1. Deploy the code.
2. Open the deployed HTTPS app, log in, and tap "Enable" on the TickBell alert prompt.
3. Check browser/site settings and confirm notifications are allowed.
4. Send a chat message from another account/device.
   - Expected: notification title is sender name.
   - Expected: body is the message preview.
5. Send a Bell from another account/device.
   - Expected: notification title includes the sender name.
   - Expected: body says to tap to respond.
6. Close the browser/app completely and send again.
   - Expected: OS notification appears if the receiving browser/platform supports Web Push.

## Platform notes

- Android Chrome/Edge PWAs support closed-app Web Push.
- Desktop Chrome/Edge support Web Push while the browser is running in the background.
- iPhone/iPad Web Push only works for installed Home Screen web apps on iOS/iPadOS 16.4+ after the user allows notifications.
- No web app can force WhatsApp-like closed-app notifications unless the user has granted notification permission and the browser/platform supports Web Push for installed web apps.
